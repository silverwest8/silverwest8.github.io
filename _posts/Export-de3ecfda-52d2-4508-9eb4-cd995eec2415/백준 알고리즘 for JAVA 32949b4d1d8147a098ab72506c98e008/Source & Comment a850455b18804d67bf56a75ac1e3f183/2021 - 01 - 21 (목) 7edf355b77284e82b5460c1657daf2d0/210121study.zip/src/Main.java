import java.util.Scanner;

public class Main {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        int e;
        int f;

        e = scanner.nextInt();
        f = scanner.nextInt();

        System.out.println((f%10)*e);
        System.out.println(((f%100)/10)*e);
        System.out.println(f/100*e);
        System.out.println((f%10)*e+((f%100)/10)*e*10+f/100*e*100);




        int a;
        int b;

        a = scanner.nextInt();
        b = scanner.nextInt();

        if (a>b) {
            System.out.println(">");
        } else if (a<b) {
            System.out.println("<");
        } else {
            System.out.println("==");
        }

        int score;
        char grade = ' ';

        score = scanner.nextInt();

        if (score >= 90){
            grade = 'A';
        } else if (score >= 80){
            grade = 'B';
        } else if (score >= 70){
            grade = 'C';
        } else if (score >= 60){
            grade = 'D';
        } else {
            grade = 'F';
        }
        System.out.println(grade);

        int year;

        year = scanner.nextInt();

        if (year%4==0 && year%100!=0 || year%400==0){
            System.out.println(1);
        } else {
            System.out.println(0);
        }


        int x;
        int y;

        x = scanner.nextInt();
        y = scanner.nextInt();

        if (x>0 && y>0){
            System.out.println(1);
        } else if (x<0 && y>0){
            System.out.println(2);
        } else if (x<0 && y<0){
            System.out.println(3);
        } else {
            System.out.println(4);
        }

        int h;
        int m;

        h = scanner.nextInt();
        m = scanner.nextInt();

        if (m >= 45) {
            System.out.print(h +" "+ (m - 45));
        } else if (m < 45 && h >= 1) {
            System.out.print((h - 1) +" "+ (m + 15));
        } else if (m < 45 && h == 0) {
            System.out.print((h + 23) +" "+ (m + 15));
        }

        int n = 0;

        n = scanner.nextInt();

        for(int i=1;i<=9;i++){
            System.out.println(n + " * " + i + " = " + n*i);
        }

        int t=0;
        t = scanner.nextInt();

        for(int i=1;i<=t;i++){
            int c;
            int d;

            c = scanner.nextInt();
            d = scanner.nextInt();

            System.out.println(c+d);

        }

        int num = 0;
        num = scanner.nextInt();
        int sum = 0;

        for (int i=1;i<=num;i++){

            sum = sum + i;

        }
        System.out.println(sum);







    }



}

