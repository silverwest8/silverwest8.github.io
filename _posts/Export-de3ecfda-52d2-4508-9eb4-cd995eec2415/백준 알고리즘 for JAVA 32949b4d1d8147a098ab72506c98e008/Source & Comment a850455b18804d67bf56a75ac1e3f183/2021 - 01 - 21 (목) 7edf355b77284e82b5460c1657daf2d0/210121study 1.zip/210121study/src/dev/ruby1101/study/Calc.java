package dev.ruby1101.study;

public class Calc {
    public static int multiply(int a, int b){
        return a*b;
    }

    public static void compare(int a, int b){
        if (a > b){
            System.out.println(">");

        }else if(a < b){
            System.out.println("<");

        }else{
            System.out.println("==");
        }
    }

    public static void result(int a){
        if( a >=90 && a<=100){
            System.out.println("A");
        }
        else if(a >=80 && a<90){
            System.out.println("B");

        }
        else if(a >=70 && a<80){
            System.out.println("C");

        }
        else if(a >=60 && a<70){
            System.out.println("D");

        }
        else{
            System.out.println("F");
        }

    }

    public static int yoonyear(int year){
        if ((year%4==0)&&!(year%100==0) || year%400 ==0){
            return 1;
        }
        return 0;
    }
    public static int quadrant(int a, int b){
        if(a>0 && b>0){
            return 1;
        }
        else if(a<0 && b>0){
            return 2;
        }
        else if(a<0 && b<0){
            return 3;
        }
        return 4;
    }

    public static void alarm(int hour, int minute){
        if (minute >= 45){
            System.out.println(hour + " " + (minute-45));

        }
        else{
            if (hour == 0){
                System.out.println(23 + " " + (60+minute-45));
            }
            else{
                System.out.println((hour-1) + " " + (60+minute-45));
            }
        }
    }

    public static void gugudan(int n){
        for( int i = 1; i<=9; i++){
            System.out.println(n + " * " + i + " = " + n*i);
        }
    }
}
