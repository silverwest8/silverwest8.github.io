package dev.ruby1101.study;

import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        int a;
        int b;
        int b1; int b10;
        int b100;
        Scanner scanner = new Scanner(System.in);
        a = scanner.nextInt();
        b = scanner.nextInt();

        b1 = b%10;
        b10 = (b-b1)%100;
        b100 = (b-b10-b1)%1000;

        System.out.println(Calc.multiply(a,b1));
        System.out.println(Calc.multiply(a,b10/10));
        System.out.println(Calc.multiply(a, b100/100));
        System.out.println(Calc.multiply(a,b));

        int x; int y;
        x = scanner.nextInt();
        y = scanner.nextInt();

        Calc.compare(x, y);

        int score;
        score = scanner.nextInt();

        Calc.result(score);

        int year;
        year = scanner.nextInt();

        System.out.println(Calc.yoonyear(year));

        int quadrantA;
        int quadrantB;

        quadrantA = scanner.nextInt();
        quadrantB = scanner.nextInt();

        System.out.println(Calc.quadrant(quadrantA,quadrantB));

        int h;
        int m;

        h = scanner.nextInt();
        m = scanner.nextInt();

        Calc.alarm(h, m);

        int n;

        n = scanner.nextInt();

        Calc.gugudan(n);

        int testCaseNum;

        testCaseNum = scanner.nextInt();

        int[][] testCases = new int[testCaseNum][3];


        for (int i = 0; i < testCaseNum; i++){
            int sum = 0;

            for(int j = 0; j < 2; j++){
                testCases[i][j] = scanner.nextInt();
                sum += testCases[i][j];

            }
            testCases[i][2] = sum;


        }

        for(int i = 0; i< testCaseNum; i++){
            System.out.println(testCases[i][2]);
        }

        int oneToN;
        int sumOfSum=0;

        oneToN = scanner.nextInt();

        for(int i = 0; i <= oneToN; i++){
            sumOfSum += i;
        }
        System.out.println(sumOfSum);







    }



}
