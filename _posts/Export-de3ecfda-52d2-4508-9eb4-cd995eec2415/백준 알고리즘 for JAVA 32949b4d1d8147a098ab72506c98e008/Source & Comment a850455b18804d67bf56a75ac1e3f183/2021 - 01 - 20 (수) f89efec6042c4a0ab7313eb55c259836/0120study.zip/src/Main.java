import java.util.Scanner;

public class Main {
    //public  어디에서나 접근이 가능하다
    //private 같은 클래스 내에서만 사용가능
    public static void main(String[] args){
        System.out.println("Hello World");
//        System.out.print("내 이름은 김예빈입니다.");
//        System.out.println("제 나이는 24..살입니다");
//        System.out.println(2+3);
//        System.out.println(2-3);
//        System.out.println(2*3);
//        System.out.println(10/3D);
        System.out.println("강한친구 대한육군");
        System.out.println("강한친구 대한육군");
        System.out.println("\\    /\\");
        System.out.println(" )  ( ')");
        System.out.println("(  /  )");
        System.out.println(" \\(__)|");
        System.out.println("|\\_/|");
        System.out.println("|q p|   /}");
        System.out.println("( 0 )\"\"\"\\");
        System.out.println("|\"^\"`    |");
        System.out.println("||_/=\\\\__|");

        Scanner scanner = new Scanner(System.in);
        int a;
        int b;

        a = scanner.nextInt();
        b = scanner.nextInt();

        System.out.println(a+b);


        int c;
        int d;

        c = scanner.nextInt();
        d = scanner.nextInt();

        System.out.println(c-d);

        int e;
        int f;

        e = scanner.nextInt();
        f = scanner.nextInt();

        System.out.println(e*f);

        int g;
        int h;

        g = scanner.nextInt();
        h = scanner.nextInt();

        System.out.println(g/(double)h);

        int i;
        int j;

        //Calc calc = new Calc();

        i = scanner.nextInt();
        j = scanner.nextInt();


        //System.out.println(calc.sum(i, j));
        System.out.println(Calc.sum(i, j));
        System.out.println(Calc.subtract(i, j));
        System.out.println(Calc.multiplication(i, j));
        System.out.println(Calc.division(i, j));
        System.out.println(Calc.remain(i, j));

        int k;
        int l;
        int m;

        k = scanner.nextInt();
        l = scanner.nextInt();
        m = scanner.nextInt();

        System.out.println((k+l)%m);
        System.out.println(((k%m)+(l%m))%m);
        System.out.println((k*l)%m);
        System.out.println(((k%m)*(l%m))%m);








    }
}
