import java.util.Scanner;
public class step1_5 {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    // int i = sc.nextInt();
    // int j = sc.nextInt();
    // System.out.print(i+j);
    System.out.print(sc.nextInt()+sc.nextInt());
  }
}
