public class step1_3 {
  public static void main(String[] args) {
    System.out.print("\\    /\\\n )  ( \')\n(  /  )\n \\(__)|");
  }
}
