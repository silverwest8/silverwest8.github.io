import java.util.Scanner;
public class step1_6 {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.print(sc.nextInt()-sc.nextInt());
  }
}
