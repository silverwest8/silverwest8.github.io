public class step1_4 {
  public static void main(String[] args) {
    System.out.print("|\\_/|\n|q p|   /}\n( 0 )\"\"\"\\\n|\"^\"`    |\n||_/=\\\\__|");
  }
}
