public class step1_2 {
  public static void main(String[] args) {
    for (int i = 0; i < 2; i++) {
      System.out.println("강한친구 대한육군");
    }
  }
}
