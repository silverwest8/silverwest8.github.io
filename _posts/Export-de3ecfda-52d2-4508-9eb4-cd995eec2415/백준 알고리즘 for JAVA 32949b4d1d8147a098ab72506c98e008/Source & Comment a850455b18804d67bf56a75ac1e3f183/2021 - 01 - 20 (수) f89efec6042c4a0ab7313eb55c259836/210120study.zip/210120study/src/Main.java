import java.util.Scanner;

public class Main {




    public static void main(String[] args){
        System.out.println("Hello World!");
        System.out.println("강한친구 대한육군");
        System.out.println("강한친구 대한육군");
        System.out.println("\\    /\\");
        System.out.println(" )  ( ')");
        System.out.println("(  /  )");
        System.out.println(" \\(__)|");
        System.out.println("|\\_/|");
        System.out.println("|q p|   /}");
        System.out.println("( 0 )\"\"\"\\");
        System.out.println("|\"^\"`    |");
        System.out.println("||_/=\\__|");





        Scanner scanner = new Scanner(System.in);

        int a;
        int b;

        a = scanner.nextInt();
        b = scanner.nextInt();
        System.out.println(a+b);

        int c;
        int d;

        c = scanner.nextInt();
        d = scanner.nextInt();

        System.out.println(c-d);

        int e;
        int f;
        e = scanner.nextInt();
        f = scanner.nextInt();

        System.out.println(e*f);

        int g;
        int h;


        g = scanner.nextInt();
        h = scanner.nextInt();

        System.out.println(g/(double)h);


        int x;
        int y;
        x = scanner.nextInt();
        y = scanner.nextInt();

        System.out.println(Calc.sum(x, y));
        System.out.println(Calc.subtract(x, y));
        System.out.println(Calc.multiply(x, y));
        System.out.println(Calc.divide(x,y));
        System.out.println(Calc.left(x, y));


        int i;
        int j;
        int k;

        i = scanner.nextInt();
        j = scanner.nextInt();
        k = scanner.nextInt();

        System.out.println((i+j)%k);
        System.out.println(((i%k)+(j%k))%k);
        System.out.println((i*j)%k);
        System.out.println(((i%k)*(j%k))%k);


    }
}



