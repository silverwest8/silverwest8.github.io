package dev.ruby1101.study;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args){

        Scanner scanner = new Scanner(System.in);

        int numOne;
        numOne = scanner.nextInt();


        for (int i = 1; i <= numOne; i++){
            System.out.println(i);
        }

        int oneNum;
        oneNum = scanner.nextInt();

        for (int i = oneNum; i >=1; i--){
            System.out.println(i);


        }

        int testCaseNum;

        testCaseNum = scanner.nextInt();

        int[][] testCases = new int[testCaseNum][3];


        for (int i = 0; i < testCaseNum; i++){
            int sum = 0;

            for(int j = 0; j < 2; j++){
                testCases[i][j] = scanner.nextInt();
                sum += testCases[i][j];

            }
            testCases[i][2] = sum;


        }

        for(int i = 0; i< testCaseNum; i++){
            System.out.println("Case #" +(i+1) + " : "+ testCases[i][2]);
        }

        int testCaseNum2;

        testCaseNum2 = scanner.nextInt();

        int[][] testCases2 = new int[testCaseNum2][3];


        for (int i = 0; i < testCaseNum2; i++){
            int sum2 = 0;

            for(int j = 0; j < 2; j++){
                testCases2[i][j] = scanner.nextInt();
                sum2 += testCases2[i][j];

            }
            testCases2[i][2] = sum2;


        }

        for(int i = 0; i< testCaseNum2; i++){
            System.out.println("Case #" +(i+1) + " : " + testCases2[i][0] + " + " + testCases2[i][1]
                    + " = " + testCases2[i][2]);


        }


        int starNum;

        starNum = scanner.nextInt();

        for (int i = 1; i<= starNum ; i++){
            for (int j = 1; j <= i ; j++){
                System.out.print("*");
            }

            System.out.println();
        }

        int starNumTwo;

        starNumTwo = scanner.nextInt();

        for (int i = 1; i<= starNumTwo ; i++){
            for (int j = 0; j < starNumTwo ; j++){
                if(j <= starNumTwo - i - 1){

                    System.out.print(" ");
                }
                else{
                    System.out.print("*");
                }
            }

            System.out.println();
        }

        int sequenceNum;
        int targetNum;
        int underTargetNum;

        sequenceNum = scanner.nextInt();
        targetNum = scanner.nextInt();

        int[] sequenceNums = new int[sequenceNum];

        for (int i = 0; i < sequenceNum; i++){
            underTargetNum = scanner.nextInt();
            if (underTargetNum < targetNum){
                    sequenceNums[i] = underTargetNum;

            }


        }

        for(int i = 0 ; i < sequenceNums.length; i++){
            if(sequenceNums[i] == 0){
                continue;

            }
            else {
                System.out.print(sequenceNums[i] + " ");
            }
        }


        int inputNumA;
        int inputNumB;



        inputNumA = scanner.nextInt();
        inputNumB = scanner.nextInt();

        List<Integer> sumOfInput = new ArrayList<Integer>();

        //동적 배열 할당하여 배열 크기에 제한을 두지 않음


        while(!(inputNumA == 0 && inputNumB == 0)){

            sumOfInput.add(inputNumA + inputNumB);



            inputNumA = scanner.nextInt();
            inputNumB = scanner.nextInt();




        }

        for(int i = 0; i <sumOfInput.size(); i++){
            System.out.println(sumOfInput.get(i));
        }




        while(scanner.hasNextInt()){    //hasNext() 메서드 :
                                        // 파일 끝(EOF)을 만났음을 알리기 위해 매크로로 정의된 EOF 값을 리턴하는 메서드
            int inputAUnlim = scanner.nextInt();
            int inputBUnlim = scanner.nextInt();

            System.out.println(inputAUnlim + inputBUnlim);

        }

        int numCycle = scanner.nextInt();

        int numCycle10;
        int numCycle1;
        int numNewCycle = -1;
        int numCycle110;
        int numOriginCycle = numCycle;

        int count = 0;

        while(numOriginCycle != numNewCycle){


            if(numCycle < 10){
                numNewCycle = numCycle*10 +numCycle;
                count+=1;
            }


            numCycle1 = numCycle % 10;
            numCycle10 = (numCycle-numCycle1)/10;
            numCycle110 = numCycle10 + numCycle1;
            if(numCycle110 >10){
                numCycle110-=10;
            }
            numNewCycle = (numCycle110) + numCycle1*10;
            count+=1;

            numCycle = numNewCycle;





        }
        System.out.println(count);


    }

}
