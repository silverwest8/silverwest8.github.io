import java.util.Scanner;

public class For11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
//for 11 X보다 작은 수
        int n = scanner.nextInt();
        int x = scanner.nextInt();

        for (int i =1;i<=n;i++){
            int list = scanner.nextInt();


            if (list<x){
                System.out.print(list + " ");
            }
        }




    }
}
