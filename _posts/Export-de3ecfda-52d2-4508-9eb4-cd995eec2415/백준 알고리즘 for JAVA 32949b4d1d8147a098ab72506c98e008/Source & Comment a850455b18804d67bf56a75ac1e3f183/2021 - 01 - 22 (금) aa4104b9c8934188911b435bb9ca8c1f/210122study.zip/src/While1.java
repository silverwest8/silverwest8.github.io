import java.util.Scanner;

public class While1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

//while 1 A + B - 5
        while (true) {
            int a = scanner.nextInt();
            int b = scanner.nextInt();
            if (a==0&&b==0) break;
            System.out.println(a + b);
        }

//while 2 A +B - 4
        while (scanner.hasNextInt()) {
            int a = scanner.nextInt();
            int b = scanner.nextInt();

            System.out.println(a + b);
        }




    }
}
