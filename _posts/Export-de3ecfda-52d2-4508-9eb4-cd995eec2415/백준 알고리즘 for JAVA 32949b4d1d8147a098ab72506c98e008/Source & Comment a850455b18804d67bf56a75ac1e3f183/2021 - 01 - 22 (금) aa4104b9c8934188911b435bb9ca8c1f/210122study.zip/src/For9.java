import java.util.Scanner;

public class For9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
//for 9 별 찍기 - 1
        int starnum = scanner.nextInt();

        for (int i = 1;i<=starnum;i++){
            for(int t=1;t<=i;t++){
                System.out.print("*");
            }
            System.out.println();
        }

//for 10 별 찍기 - 2
        int starnumber = scanner.nextInt();


        for (int i = 1;i<=starnumber;i++){
            for(int b=1;b<=starnumber-i;b++) {
                System.out.print(" ");
            }
            for(int k=1;k<=i;k++){
                System.out.print("*");
            }
            System.out.println();
        }


    }
}
