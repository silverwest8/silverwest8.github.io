import java.util.Scanner;

public class While3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int m,count=0;
        m = n;

        while (true){
            int t = n/10;
            int o = n%10;
            n = o*10+((t+o)%10);
//            System.out.println(n);
            count += 1;
            if (m==n) {
                System.out.println(count);
                break;
            }

        }






    }
}
