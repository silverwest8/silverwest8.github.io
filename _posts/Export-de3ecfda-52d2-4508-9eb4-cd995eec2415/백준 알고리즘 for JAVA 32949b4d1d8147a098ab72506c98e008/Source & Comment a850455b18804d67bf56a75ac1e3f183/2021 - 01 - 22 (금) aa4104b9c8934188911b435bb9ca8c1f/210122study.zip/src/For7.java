import java.util.Scanner;

public class For7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

//for 7 A+B -7
        int t;
        t = scanner.nextInt();

        for (int i = 1; i <= t; i++) {

            int c = scanner.nextInt();
            int d = scanner.nextInt();

            System.out.println("Case #" + i + ": " + (c + d));
        }

//for 8 A+B -8
        int tt;
        tt = scanner.nextInt();

        for (int i = 1; i <= tt; i++) {

            int e = scanner.nextInt();
            int f = scanner.nextInt();

            System.out.println("Case #" + i + ": " + e + " + " + f + " = " + (e + f));
        }
    }
}
