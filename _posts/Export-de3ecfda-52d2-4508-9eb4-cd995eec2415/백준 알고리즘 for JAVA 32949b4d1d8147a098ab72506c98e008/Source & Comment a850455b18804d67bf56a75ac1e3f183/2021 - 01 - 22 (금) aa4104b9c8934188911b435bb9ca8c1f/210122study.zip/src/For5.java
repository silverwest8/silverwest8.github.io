import java.util.Scanner;

public class For5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

//for 5 N 찍기
        int number;
        number = scanner.nextInt();

        for (int i = 1; i <= number; i++) {
            System.out.println(i);
        }

//for 6 기찍 N
        int num;
        num = scanner.nextInt();

        for (int i = num; i > 0; i--) {
            System.out.println(i);
        }

    }
}
